<?php

namespace Kanboard\Core\Controller;

/**
 * Class AccessForbiddenException
 *
 * @package Kanboard\Core\Controller
 * @author  Frederic Guillot
 */
class AccessForbiddenException extends BaseException
{

}
