<?php

namespace Kanboard\Core\Plugin;

/**
 * Class PluginInstallerException
 *
 * @package Kanboard\Core\Plugin
 * @author  Frederic Guillot
 */
class PluginInstallerException extends PluginException
{
}
